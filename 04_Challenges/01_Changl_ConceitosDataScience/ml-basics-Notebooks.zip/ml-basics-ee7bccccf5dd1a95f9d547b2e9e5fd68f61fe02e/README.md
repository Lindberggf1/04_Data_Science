# Machine Learning Basics

This repository contains the exercise files for the [Create machine learning models](https://docs.microsoft.com/learn/paths/create-machine-learn-models/) learning path on Microsoft Learn.

## Contributing

We are not currently accepting external contributions for this repo. If you encounter any problems, please report an issue.
